# Instedro — rede social Java + Spring Boot

MVP inicial com cadastro/login, feed, criação de publicações e curtidas. Interface responsiva em português.

## Requisitos para rodar no computador
- Java 21+
- Maven 3.9+

## Executar localmente
No terminal, dentro da pasta `instedro`:

```bash
mvn spring-boot:run
```

Abra `http://localhost:8080`. Sem configuração adicional, usa H2 local em arquivo (`./data/instedro`). Para gerar um JAR:

```bash
mvn clean package
java -jar target/instedro-0.0.1-SNAPSHOT.jar
```

## Recursos incluídos
- Cadastro de usuário com validação de campos e senha armazenada com BCrypt.
- Login/logout usando Spring Security e proteção CSRF padrão.
- Feed ordenado pelas publicações mais recentes.
- Criar publicação de até 500 caracteres.
- Curtidas básicas.
- PostgreSQL opcional para produção; H2 para desenvolvimento.

## Variáveis para PostgreSQL em produção
Configure estas variáveis no ambiente de hospedagem. Use a URL JDBC fornecida pelo provedor, não a URL no formato `postgres://`:

- `DATABASE_URL=jdbc:postgresql://HOST:5432/NOME_BANCO?sslmode=require`
- `DB_USER=USUARIO`
- `DB_PASSWORD=SENHA`
- `DB_DRIVER=org.postgresql.Driver`
- `DB_DIALECT=org.hibernate.dialect.PostgreSQLDialect`
- `DDL_AUTO=update`
- `PORT` geralmente é fornecida automaticamente pela plataforma.

Nunca publique senhas do banco ou segredos no GitHub. Em produção, prefira migrações de banco (Flyway) e `DDL_AUTO=validate` depois de preparar o schema.

## Publicar gratuitamente (sugestão: Render + Neon)
1. Crie uma conta no GitHub e um repositório chamado `instedro`. Envie todos os arquivos desta pasta, incluindo `Dockerfile`.
2. Crie um projeto PostgreSQL no Neon (plano Free) e copie os dados de conexão. O plano e os limites podem mudar; confira a página oficial.
3. No Render, escolha **New → Web Service** e conecte o repositório GitHub `instedro`. Selecione ambiente **Docker** (o projeto já inclui um Dockerfile).
4. Escolha o plano gratuito, se estiver disponível na sua conta/região. O serviço pode dormir após inatividade e demorar um pouco para abrir de novo.
5. Em **Environment**, adicione `DATABASE_URL` com a URL JDBC do Neon, no formato `jdbc:postgresql://HOST/DB?sslmode=require`; `DB_USER` com o usuário do banco; `DB_PASSWORD` com a senha; `DB_DRIVER` como `org.postgresql.Driver`; `DB_DIALECT` como `org.hibernate.dialect.PostgreSQLDialect`; `DDL_AUTO` como `update`. Use os valores reais exibidos pelo Neon e mantenha as credenciais privadas. Se o provedor fornecer uma URI `postgresql://...`, converta o prefixo para `jdbc:postgresql://...` e confira host, banco e parâmetros SSL.
6. Clique em **Create Web Service** e aguarde o build. Abra a URL `onrender.com` que aparecer no painel.
7. Teste cadastro, login, publicação e curtida.

Render oferece web services gratuitos com limitações e suspensão por inatividade; o banco gratuito do Render expira após 30 dias, por isso esta sugestão usa Neon para o PostgreSQL. Confira os limites atuais nas páginas oficiais: https://render.com/docs/free e https://neon.com/docs/introduction/plans. Um frontend estático como Netlify sozinho não executa o backend Spring Boot.

## Limitações desta versão
- Curtidas são um contador simples, então a mesma pessoa pode curtir várias vezes. Deve ser melhorado antes de abrir ao público.
- Não há upload de fotos, comentários, seguir usuários, recuperação de senha ou moderação nesta primeira versão.
- Não use dados reais importantes até configurar HTTPS, backup, política de privacidade, rate limiting e testes de segurança.
