package com.instedro.app.repository;
import com.instedro.app.model.Post;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface PostRepository extends JpaRepository<Post,Long> { List<Post> findAllByOrderByCreatedAtDesc(); }
