package com.instedro.app.web;

import com.instedro.app.model.AppUser;
import com.instedro.app.model.Post;
import com.instedro.app.repository.PostRepository;
import com.instedro.app.repository.UserRepository;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class SocialController {
 private final UserRepository users; private final PostRepository posts; private final PasswordEncoder encoder;
 public SocialController(UserRepository users,PostRepository posts,PasswordEncoder encoder){this.users=users;this.posts=posts;this.encoder=encoder;}
 @GetMapping("/") public String home(){return "redirect:/feed";}
 @GetMapping("/login") public String login(){return "login";}
 @GetMapping("/register") public String registerForm(Model model){if(!model.containsAttribute("form"))model.addAttribute("form",new RegisterForm());return "register";}
 @PostMapping("/register") public String register(@Valid @ModelAttribute("form") RegisterForm form, BindingResult result, RedirectAttributes redirect){
  if(users.existsByUsername(form.username)){result.rejectValue("username","duplicate","Esse nome de usuário já está em uso.");}
  if(users.existsByEmail(form.email)){result.rejectValue("email","duplicate","Esse e-mail já está cadastrado.");}
  if(!form.password.equals(form.confirmPassword)){result.rejectValue("confirmPassword","mismatch","As senhas não coincidem.");}
  if(result.hasErrors()){redirect.addFlashAttribute("org.springframework.validation.BindingResult.form",result);redirect.addFlashAttribute("form",form);return "redirect:/register";}
  AppUser user=new AppUser();user.setUsername(form.username.trim());user.setEmail(form.email.trim().toLowerCase());user.setPassword(encoder.encode(form.password));users.save(user);
  redirect.addFlashAttribute("success","Conta criada! Agora entre com seu usuário e senha.");return "redirect:/login";
 }
 @GetMapping("/feed") public String feed(Model model,Authentication auth){model.addAttribute("posts",posts.findAllByOrderByCreatedAtDesc());model.addAttribute("username",auth.getName());model.addAttribute("postCount",posts.count());return "feed";}
 @PostMapping("/posts") public String createPost(@RequestParam @NotBlank @Size(max=500) String content,Authentication auth,RedirectAttributes redirect){
  String cleaned=content.trim();if(cleaned.isEmpty()||cleaned.length()>500){redirect.addFlashAttribute("error","A publicação precisa ter entre 1 e 500 caracteres.");return "redirect:/feed";}
  AppUser author=users.findByUsername(auth.getName()).orElseThrow();posts.save(new Post(author,cleaned));return "redirect:/feed";
 }
 @PostMapping("/posts/{id}/like") public String like(@PathVariable Long id){posts.findById(id).ifPresent(p->{p.setLikesCount(p.getLikesCount()+1);posts.save(p);});return "redirect:/feed";}
 public static class RegisterForm {
  @NotBlank @Size(min=3,max=24) @Pattern(regexp="[A-Za-z0-9_.]+",message="Use letras, números, ponto ou underline.") public String username="";
  @NotBlank @Email public String email="";
  @NotBlank @Size(min=8,max=72,message="Use pelo menos 8 caracteres.") public String password="";
  @NotBlank public String confirmPassword="";
  public String getUsername(){return username;} public void setUsername(String v){username=v;}
  public String getEmail(){return email;} public void setEmail(String v){email=v;}
  public String getPassword(){return password;} public void setPassword(String v){password=v;}
  public String getConfirmPassword(){return confirmPassword;} public void setConfirmPassword(String v){confirmPassword=v;}
 }
}
