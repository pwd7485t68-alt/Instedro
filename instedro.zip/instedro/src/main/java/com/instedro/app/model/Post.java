package com.instedro.app.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

@Entity
@Table(name="posts")
public class Post {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  @ManyToOne(optional=false,fetch=FetchType.EAGER) private AppUser author;
  @NotBlank @Size(max=500) @Column(nullable=false,length=500) private String content;
  @Column(nullable=false) private LocalDateTime createdAt = LocalDateTime.now();
  private int likesCount = 0;
  protected Post(){}
  public Post(AppUser author,String content){this.author=author;this.content=content;this.createdAt=LocalDateTime.now();}
  public Long getId(){return id;} public AppUser getAuthor(){return author;} public String getContent(){return content;} public LocalDateTime getCreatedAt(){return createdAt;} public int getLikesCount(){return likesCount;} public void setLikesCount(int n){likesCount=n;}
}
