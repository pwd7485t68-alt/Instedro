package com.instedro.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InstedroApplication {
  public static void main(String[] args) { SpringApplication.run(InstedroApplication.class, args); }
}
