package com.instedro.app.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

@Entity
@Table(name="app_users")
public class AppUser {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  @NotBlank @Size(min=3,max=24) @Column(nullable=false,unique=true,length=24) private String username;
  @NotBlank @Email @Column(nullable=false,unique=true) private String email;
  @Column(nullable=false) private String password;
  @Column(length=160) private String bio = "Novo por aqui ✨";
  @Column(nullable=false) private LocalDateTime createdAt = LocalDateTime.now();
  public Long getId(){return id;} public String getUsername(){return username;} public void setUsername(String v){username=v;}
  public String getEmail(){return email;} public void setEmail(String v){email=v;} public String getPassword(){return password;} public void setPassword(String v){password=v;}
  public String getBio(){return bio;} public void setBio(String v){bio=v;} public LocalDateTime getCreatedAt(){return createdAt;}
}
