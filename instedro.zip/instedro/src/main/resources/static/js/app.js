const composer = document.querySelector('textarea[name="content"]');
const counter = document.getElementById('char-count');
if (composer && counter) {
  const update = () => { counter.textContent = composer.value.length; };
  composer.addEventListener('input', update); update();
}
